1) Check out code with git.

Every time you make changes:
1) git checkout master
2) git pull
3) git checkout [YOUR_NAME](so either ting or veso)
4) git merge main
5) Make all the changes you want and test the changes in a browser (by opening up the relevant minigame html file)
6) To see files you changed: git status
7) git add [FILENAMES/DIRECTORIES]
8) git commit (and put a descriptive commit message)
9) Repeat 5-8 for all related changes.
10) git push
11) Go to https://github.com/Janu-Q/simple and make a pull request with Sam as a reviewer.

Note: place all images under assets right now. We'll reorganize it later.

The latest for demo:
simple-dmf.pages.dev

The latest for each person:
simple-sam.pages.dev
simple-ting.pages.dev
simple-veso.pages.dev
